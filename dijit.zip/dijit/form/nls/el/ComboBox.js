define(
({
		previousMessage: "Προηγούμενες επιλογές",
		nextMessage: "Περισσότερες επιλογές"
})
);
