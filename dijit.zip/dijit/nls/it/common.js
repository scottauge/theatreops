define(
({
	buttonOk: "Ok",
	buttonCancel: "Annulla",
	buttonSave: "Salva",
	itemClose: "Chiudi"
})
);
