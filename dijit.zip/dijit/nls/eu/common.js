define({      
//begin v1.x content
	buttonOk: "Ados",
	buttonCancel: "Utzi",
	buttonSave: "Gorde",
	itemClose: "Itxi"
//end v1.x content
});

