define({      
//begin v1.x content
	loadingState: "Kargatzen...",
	errorState: "Barkatu, errorea gertatu da"
//end v1.x content
});

