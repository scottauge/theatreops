define(
({
	buttonOk: "OK",
	buttonCancel: "Zrušiť",
	buttonSave: "Uložiť",
	itemClose: "Zatvoriť"
})
);
