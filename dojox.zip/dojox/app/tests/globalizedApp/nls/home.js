define({
	root: {
		label1: "Label One",
		label2: "Label Two"
	},
	fr: true
});