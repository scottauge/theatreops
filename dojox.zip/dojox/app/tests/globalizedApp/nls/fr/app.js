define({
	home: "Maison",
   	label0: "Etiquette 0"
});