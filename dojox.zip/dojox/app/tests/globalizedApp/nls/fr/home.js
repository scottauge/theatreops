define({
	label1: "Etiquette Un",
	label2: "Etiquette Deux"
});