define({
	root: {
	  home: "Home",
	  label0: "Label Zero"
	},
	fr: true
});