define([], function(){
	return {
		oldRepl: "Fruit: ",
		items: ["apple", "banana", "orange"]
	}
});