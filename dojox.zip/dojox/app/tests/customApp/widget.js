define([], function(){
	return {
		label: "test label"
	}
});