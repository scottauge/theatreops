define([], function(){
	return {
		init: function(){
			throw new Error("error1-error");
		}
	}
});