(function(){
	require.has = {
	    "dojo-publish-privates": true
	};
})();