define([], function(){
	throw new Error("error2-error");
	return {
		init: function(){
		}
	}
});