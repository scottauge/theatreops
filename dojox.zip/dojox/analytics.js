define(["./analytics/_base"], function(analytics) {
	/*=====
	 return {
		 // summary:
		 //		Deprecated.  Should require dojox/analytics modules directly rather than trying to access them through
		 //		this module.
	 };
	 =====*/
	return analytics;
});
