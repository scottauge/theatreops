define({      
//begin v1.x content
	add: "Dodaj",
	addAuthor: "Dodaj autora",
	addContributor: "Dodaj saradnika"
//end v1.x content
});

