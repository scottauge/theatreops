define(
({
	"deleteButton" : "[Sil]"
})
);
