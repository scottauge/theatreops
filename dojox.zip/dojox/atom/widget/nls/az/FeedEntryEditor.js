define(
({
	"edit" : "[tərtib et]",
	"save" : "[saxla]",
	"cancel" : "[ləğv et]",
	"doNew" : "[yeni]"
})
);
