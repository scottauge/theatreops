define(
({
	add: "اضافة",
	addAuthor: "اضافة مؤلف",
	addContributor: "اضافة مشارك"
})
);
