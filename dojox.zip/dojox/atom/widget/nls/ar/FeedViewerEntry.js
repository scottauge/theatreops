define(
({
	deleteButton: "[حذف]"
})
);
