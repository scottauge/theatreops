define(
({
	add: "Добави",
	addAuthor: "Добави автор",
	addContributor: "Добави сътрудник"
})
);
