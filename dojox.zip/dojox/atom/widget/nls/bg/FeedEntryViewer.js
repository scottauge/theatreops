define(
({
	displayOptions: "[опция за показване]",
	title: "Заглавие",
	authors: "Автори",
	contributors: "Сътрудници",
	id: "Идентификатор",
	close: "[затвори]",
	updated: "Обновен",
	summary: "Обобщение",
	content: "Съдържание"
})
);
