define(
({
	deleteButton: "[Изтрий]"
})
);
