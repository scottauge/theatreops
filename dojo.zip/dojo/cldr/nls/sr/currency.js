define(
//begin v1.x content
{
	"HKD_displayName": "Хонгконшки долар",
	"CHF_displayName": "Швајцарски франак",
	"JPY_symbol": "¥",
	"CAD_displayName": "Канадски долар",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Кинески јуан",
	"AUD_displayName": "Аустралијски долар",
	"JPY_displayName": "Јапански јен",
	"USD_displayName": "Амерички долар",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Британска фунта",
	"GBP_symbol": "£",
	"AUD_symbol": "AUD",
	"EUR_displayName": "Евро"
}
//end v1.x content
);