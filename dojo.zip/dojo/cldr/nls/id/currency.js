define(
//begin v1.x content
{
	"HKD_displayName": "Dolar Hong Kong",
	"CHF_displayName": "Franc Swiss",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Dolar Kanada",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Yuan China",
	"USD_symbol": "US$",
	"AUD_displayName": "Dolar Australia",
	"JPY_displayName": "Yen Jepang",
	"CAD_symbol": "CA$",
	"USD_displayName": "Dolar Amerika Serikat",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Pound Inggris",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);