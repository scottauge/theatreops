define(
//begin v1.x content
{
	"HKD_displayName": "hongkonský dolár",
	"CHF_displayName": "švajčiarsky frank",
	"JPY_symbol": "JPY",
	"CAD_displayName": "kanadský dolár",
	"HKD_symbol": "HKD",
	"CNY_displayName": "čínsky jüan",
	"USD_symbol": "USD",
	"AUD_displayName": "austrálsky dolár",
	"JPY_displayName": "japonský jen",
	"CAD_symbol": "CAD",
	"USD_displayName": "americký dolár",
	"EUR_symbol": "€",
	"CNY_symbol": "CNY",
	"GBP_displayName": "britská libra",
	"GBP_symbol": "GBP",
	"AUD_symbol": "AUD",
	"EUR_displayName": "euro"
}
//end v1.x content
);